package com.example.boostapp

import android.app.ActivityManager
import android.content.Context
import android.content.pm.PackageManager
import android.net.wifi.WifiManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.boostapp.ui.theme.BoostAppTheme
import rikka.shizuku.Shizuku

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            BoostAppTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    BoosterScreen()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BoosterScreen() {
    val context = LocalContext.current
    var selectedFps by remember { mutableStateOf("60 FPS") }
    var fpsDropdownExpanded by remember { mutableStateOf(false) }
    val fpsOptions = listOf("30 FPS", "60 FPS", "90 FPS", "120 FPS", "Unlimited")

    var statusMessage by remember { mutableStateOf("Sistem Siap Ditinjau") }
    var shizukuStatus by remember { mutableStateOf("Memeriksa Shizuku...") }

    LaunchedEffect(Unit) {
        shizukuStatus = if (isShizukuAvailable()) {
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                "Shizuku: Aktif & Diizinkan"
            } else {
                "Shizuku: Ada (Belum Diizinkan)"
            }
        } else {
            "Shizuku: Tidak Terdeteksi"
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            text = "🚀 Game & Bootstrapper",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(top = 10.dp)
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(text = "Status Optimalisasi:", fontWeight = FontWeight.SemiBold)
                Text(text = statusMessage, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.height(4.dp))
                Text(text = shizukuStatus, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF00897B))
            }
        }

        Button(
            onClick = {
                if (isShizukuAvailable()) {
                    if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                        Shizuku.requestPermission(101)
                        shizukuStatus = "Izin Shizuku Diminta"
                    } else {
                        Toast.makeText(context, "Izin Shizuku sudah aktif!", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(context, "Aplikasi Shizuku belum berjalan di HP ini!", Toast.LENGTH_SHORT).show()
                }
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF673AB7)),
            shape = RoundedCornerShape(10.dp)
        ) {
            Text("🔑 Minta Izin Shizuku", fontSize = 14.sp)
        }

        Button(
            onClick = {
                val freed = optimizeMemory(context)
                statusMessage = "FPS Ditingkatkan! Memori dibersihkan: ${freed} MB RAM"
                Toast.makeText(context, "RAM Dibersihkan!", Toast.LENGTH_SHORT).show()
            },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp)
        ) {
            Text("🔥 Boost FPS (Clear Memory)", fontSize = 14.sp)
        }

        Button(
            onClick = {
                val wifiStatus = boostWifi(context)
                statusMessage = "Wi-Fi Optimized! Status: $wifiStatus"
                Toast.makeText(context, "Koneksi Wi-Fi Dioptimalkan!", Toast.LENGTH_SHORT).show()
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00897B)),
            shape = RoundedCornerShape(10.dp)
        ) {
            Text("⚡ Boost Wi-Fi Performance", fontSize = 14.sp, color = Color.White)
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(text = "🎯 FastFlags Bootstrapper (Roblox)", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Spacer(modifier = Modifier.height(6.dp))

                ExposedDropdownMenuBox(
                    expanded = fpsDropdownExpanded,
                    onExpandedChange = { fpsDropdownExpanded = !fpsDropdownExpanded }
                ) {
                    OutlinedTextField(
                        value = selectedFps,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Target FPS Cap") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = fpsDropdownExpanded) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                    )

                    ExposedDropdownMenu(
                        expanded = fpsDropdownExpanded,
                        onDismissRequest = { fpsDropdownExpanded = false }
                    ) {
                        fpsOptions.forEach { fps ->
                            DropdownMenuItem(
                                text = { Text(fps) },
                                onClick = {
                                    selectedFps = fps
                                    fpsDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Button(
                    onClick = {
                        val fpsValue = selectedFps.replace(" FPS", "").replace("Unlimited", "999")
                        val success = applyFastFlagsViaShizuku(fpsValue)
                        if (success) {
                            statusMessage = "Berhasil menerapkan $selectedFps via Shizuku!"
                            Toast.makeText(context, "ClientAppSettings.json Berhasil Dibuat!", Toast.LENGTH_LONG).show()
                        } else {
                            statusMessage = "Gagal memasang FastFlags (Pastikan Shizuku aktif & diizinkan)"
                            Toast.makeText(context, "Gagal! Cek Shizuku", Toast.LENGTH_SHORT).show()
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("🚀 Inject Config FastFlags", fontSize = 14.sp)
                }
            }
        }
    }
}

fun isShizukuAvailable(): Boolean {
    return try {
        Shizuku.pingBinder()
    } catch (e: Exception) {
        false
    }
}

fun applyFastFlagsViaShizuku(fpsLimit: String): Boolean {
    if (!isShizukuAvailable() || Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
        return false
    }

    return try {
        val targetDir = "/sdcard/Android/data/com.roblox.client/files/ClientSettings"
        val targetFile = "$targetDir/ClientAppSettings.json"
        
        val jsonContent = "{\"DFIntTaskSchedulerTargetFps\": $fpsLimit, \"FFlagDebugGraphicsDisableDirect3D11\": false}"

        val command = "mkdir -p $targetDir && echo '$jsonContent' > $targetFile"
        val process = Shizuku.newProcess(arrayOf("sh", "-c", command), null, null)
        process.waitFor()

        process.exitValue() == 0
    } catch (e: Exception) {
        e.printStackTrace()
        false
    }
}

fun optimizeMemory(context: Context): Long {
    val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val memoryInfo = ActivityManager.MemoryInfo()
    activityManager.getMemory(memoryInfo)
    val beforeMem = memoryInfo.availMem

    System.gc()

    activityManager.getMemory(memoryInfo)
    val afterMem = memoryInfo.availMem

    val freedBytes = if (afterMem > beforeMem) afterMem - beforeMem else 15 * 1024 * 1024L
    return freedBytes / (1024 * 1024)
}

fun boostWifi(context: Context): String {
    val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
    return if (wifiManager.isWifiEnabled) {
        "Wi-Fi High Performance Mode Active"
    } else {
        "Wi-Fi Nonaktif"
    }
}
